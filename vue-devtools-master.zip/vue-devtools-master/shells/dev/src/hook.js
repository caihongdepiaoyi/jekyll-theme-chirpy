import { installHook } from 'src/backend/hook'

installHook(window)
